/********************************** (C) COPYRIGHT *******************************
 * File Name          : Main.c
 * Author             : CanHobby.ca
 * Version            : V1.0
 * Date               : 2026/05/06
 * Description        :
 *******************************************************************************/

#include "CH57x_common.h"
#define  LED_pin GPIO_Pin_8

/*********************************************************************
 * @fn      main
***/

int main()
{
    SetSysClock(CLK_SOURCE_PLL_60MHz);

    GPIOA_ModeCfg( LED_pin, GPIO_ModeOut_PP_20mA);

    while(1) {

    DelayMs( 400 );

    GPIOA_SetBits( LED_pin );

    DelayMs( 400 );

    GPIOA_ResetBits( LED_pin );

    }
}